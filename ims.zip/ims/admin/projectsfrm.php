<?php
//include("backg.php");
//   include_once("include/checksession.php");
 // $uid = $_GET["uid"];

?>
<?php	
	include("backg.php");
	include_once("include/config.php");
?>
<!DOCTYPE html>
<html>
<body>

<iframe src="projects.php" width="100%" height="550">
  <p>Your browser does not support iframes.</p>
</iframe>

</body>
</html>
