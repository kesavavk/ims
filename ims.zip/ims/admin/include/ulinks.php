<table>
<tr>
<td width="80" align="center"><a href="home.php">Home</a></td><td></td>
<td width="70"><a href="ureports.php">Reports</a></td>
<td width="130"><a href="changepassword.php">Change Password</a></td>
<td width="100" align="left"><a href="logout.php">Log Out</a></td>
</tr>
</table>