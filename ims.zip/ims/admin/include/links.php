<table>
<tr>
<td width="60" align="center"><a href="admin.php?uid=<?php echo $uid?>">Home</a></td>
<td width="125"><a href="changepassword.php?uid=<?php echo $uid?>">Change Password</a></td>
<td width="100"><a href="user.php?uid=<?php echo $uid?>">Manage User</a></td>
<td width="130"><a href="nwdays.php?show=1&uid=<?php echo $uid?>">Non Working Days</a></td>

<td width="90"><a href="aureports.php?uid=<?php echo $uid?>">User's Detail</a></td>
<td width="40"><a href="fine.php?uid=<?php echo $uid?>">Fine</a></td>
<td width="70"><a href="news.php?uid=<?php echo $uid?>">Message</a></td>
<td width="60"><a href="groups.php?uid=<?php echo $uid?>">Groups</a></td>
<td width="80" align="left"><a href="logout.php">Log Out</a></td>
</tr>
</table>
