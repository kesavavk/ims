<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<?php
	include_once("include/config.php");
	//include("include/checksession.php");
	//$user = $_SESSION["uname"];
	//$fname = $_SESSION["fname"];
	
?>
<html>
<head>
	<link href="css/style.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html;">
<style type="text/css">

</style>
</head>
<body>
				 
					<div id="pos">
				 <div id="menu">
								<div>
		          
						
					  <ul id="nav">
							
						  <li id="active"><a href="Projectsfrm.php">Projects</a></li>
					   <li id="active"><a href="bomlistfrm.php">BOM List</a></li>
					   <li id="active"><a href="userfrm.php">User</a></li>
					      <li id="active"><a href="../logout.php">Logout</a></li>
					   
					   
					   
					 </ul>
					 </div></div>

</body>
<!--<div style=" position: fixed; width: 95%; bottom: 0px; left: 0px; height:20px; color: white; -moz-box-shadow: 0pt 0pt 10px white;-moz-border-radius-topleft:12px; -moz-border-radius-topright:12px;"><center><font color="white" size="1"><b>Copyrights &copy;  <a href="http://www.spl.com"> SPL/IT, </a> 2015-2016 - All rights reserved</font></b></font></center></div>
-->
</html>
